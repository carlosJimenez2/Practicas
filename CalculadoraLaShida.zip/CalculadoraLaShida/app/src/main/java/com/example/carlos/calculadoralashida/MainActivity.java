package com.example.carlos.calculadoralashida;

import android.content.Intent;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.CheckBox;
import android.text.TextUtils;

public class MainActivity extends AppCompatActivity {

    private EditText editText1;
    private EditText editText2;
    private TextView textView1;
    private RadioButton radioButton1;
    private RadioButton radioButton2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText1 = (EditText) findViewById(R.id.txt_1);
        editText2 = (EditText) findViewById(R.id.txt_2);
        textView1 = (TextView) findViewById(R.id.txt_resultado);
        radioButton1 = (RadioButton) findViewById(R.id.radioButtonSuma);
        radioButton2 = (RadioButton) findViewById(R.id.radioButtonResta);
    }
    public void Suma(View view)
    {
        if (editText1.length()==0 || editText2.length()==0) {
            String ResString = "Hacen falta datos, compi";
            textView1.setText(ResString);
        }
        else{
            String Val1T = editText1.getText().toString();
            String Val2T = editText2.getText().toString();

            double Val1Int = Double.parseDouble(Val1T);
            double Val2Int = Double.parseDouble(Val2T);

            double Result = 0;



            if (radioButton1.isChecked() == false && radioButton2.isChecked() == false) {
                String ResString = "Selecciona una operación";
                textView1.setText(ResString);
            } else {
                if (Val1Int > 999 || Val2Int > 999) {
                    String ResStrig = "3 dígitos máximo, prro";

                    textView1.setText(ResStrig);
                } else if (Val1Int < -999 || Val2Int < -999) {
                    String ResStrig = "3 dígitos máximo, prro";

                    textView1.setText(ResStrig);
                } else {

                    if (radioButton2.isChecked() == true) {
                        Result = Val1Int - Val2Int;

                    } else {
                        Result = Val1Int + Val2Int;
                    }

                    String ResStrig = String.valueOf(Result);

                    textView1.setText(ResStrig);
                }

            }
        }
    }

    public void Quitar (View view)
    {
        editText1.setText(null);
        editText2.setText(null);

        String ResStrig = "";

        textView1.setText(ResStrig);
    }



}
